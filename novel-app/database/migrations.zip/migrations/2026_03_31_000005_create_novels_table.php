<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('novels', function (Blueprint $table) {
    $table->id();
    $table->foreignId('user_id')->constrained()->cascadeOnDelete();
    $table->string('title');
    $table->text('description')->nullable();
    $table->string('cover')->nullable();
    $table->enum('status',['draft','published'])->default('draft');
    $table->integer('view_count')->default(0);
    $table->timestamps();
});
    }
    public function down(): void
    {
        Schema::dropIfExists('novels');
    }
};